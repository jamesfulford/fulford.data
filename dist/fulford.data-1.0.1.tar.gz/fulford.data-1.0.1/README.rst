fulford.data
=======================

Declarative processing, transforming, and validating of data.

Brought to you by James Fulford.
